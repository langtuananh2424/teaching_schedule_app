import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // Sử dụng theme để tùy chỉnh font chữ toàn cục nếu cần
      theme: ThemeData(fontFamily: 'Roboto'), // Ví dụ
      home: ScheduleScreen(),
    );
  }
}

class ScheduleScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            // Thêm hành động quay lại, ví dụ: Navigator.pop(context);
          },
        ),
        title: Row(
          children: [
            Text('Quay lại'),
            Spacer(),
            CircleAvatar(
              backgroundColor: Colors.grey.shade300,
              radius: 18,
              // Thêm hình ảnh hoặc chữ cái đầu của người dùng
              // child: Text('A'),
            ),
          ],
        ),
        backgroundColor: Colors.blue,
        elevation: 2, // Thêm bóng đổ cho AppBar
      ),
      body: Column(
        children: [
          // --- PHẦN LỊCH TUẦN ĐÃ ĐƯỢC CẢI TIẾN ---
          buildWeekCalendar(),

          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 8.0),
              // Sử dụng ListView.builder để tối ưu hiệu suất cho danh sách dài
              itemCount: scheduleData.length,
              itemBuilder: (context, index) {
                final item = scheduleData[index];
                return ScheduleItem(
                  time: item['time']!,
                  subject: item['subject']!,
                  room: item['room']!,
                  status: item['status']!,
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // Widget mới để xây dựng phần lịch tuần một cách linh hoạt
  Widget buildWeekCalendar() {
    final List<String> daysOfWeek = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'];
    final List<String> dates = ['19', '20', '21', '22', '23', '24', '25'];

    return Container(
      color: Colors.blue,
      padding: const EdgeInsets.symmetric(vertical: 12.0),
      child: Row(
        // Sử dụng Expanded để các cột tự chia đều không gian
        children: List.generate(daysOfWeek.length, (index) {
          // Bọc mỗi cặp ngày/thứ trong Expanded
          return Expanded(
            child: Column(
              children: [
                Text(
                  daysOfWeek[index],
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
                ),
                SizedBox(height: 8),
                // Thêm một vòng tròn để làm nổi bật ngày được chọn
                CircleAvatar(
                  radius: 16,
                  backgroundColor: index == 2 ? Colors.white : Colors.transparent, // Ví dụ: ngày 21 (T4) được chọn
                  child: Text(
                    dates[index],
                    style: TextStyle(
                      color: index == 2 ? Colors.blue : Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}



class ScheduleItem extends StatelessWidget {
  final String time;
  final String subject;
  final String room;
  final String status;

  ScheduleItem({required this.time, required this.subject, required this.room, required this.status});

  @override
  Widget build(BuildContext context) {
    Color statusColor;
    // ... (Phần switch case giữ nguyên)
    switch (status) {
      case 'Hoàn thành':
        statusColor = Colors.green;
        break;
      case 'Sắp diễn ra':
        statusColor = Colors.orange.shade700;
        break;
      case 'Đầy đủ':
        statusColor = Colors.blue;
        break;
      case 'Nghỉ':
        statusColor = Colors.red;
        break;
      default:
        statusColor = Colors.black;
    }

    // **THAY ĐỔI Ở ĐÂY**
    return Padding(
      // Tăng giá trị `bottom` để giãn khoảng cách. Ví dụ: từ 8.0 lên 12.0
      padding: const EdgeInsets.only(bottom: 12.0),
      child: SizedBox(
        width: double.infinity,
        child: ElevatedButton(
          onPressed: () {
            print('Đã nhấn vào môn: $subject');
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Đã chọn môn: $subject'),
                duration: Duration(seconds: 1),
              ),
            );
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFAEE4FF),
            foregroundColor: Colors.black,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
            elevation: 2,
          ),
          child: IntrinsicHeight(
            child: Row(
              children: [
                // ... (Nội dung bên trong của Row giữ nguyên)
                Center(
                  child: Text(
                    time,
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.red.shade700),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        subject,
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                        softWrap: true,
                      ),
                      const SizedBox(height: 5),
                      Text(
                        room,
                        style: TextStyle(color: Colors.grey.shade800, fontSize: 14),
                      ),
                    ],
                  ),
                ),
                Center(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: statusColor.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      status,
                      style: TextStyle(color: statusColor, fontWeight: FontWeight.bold, fontSize: 13),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


// Tách dữ liệu ra khỏi UI để dễ quản lý
final List<Map<String, String>> scheduleData = [
  {
    'time': '7:00',
    'subject': 'Mang máy tính, 64KTPM3',
    'room': '329-A2',
    'status': 'Hoàn thành',
  },
  {
    'time': '9:45',
    'subject': 'Mang máy tính, 64KTPM5',
    'room': '327-A2',
    'status': 'Sắp diễn ra',
  },
  {
    'time': '12:55',
    'subject': 'Quản trị mạng và hệ thống phân tán, 64HTTT1',
    'room': '325-A2',
    'status': 'Đầy đủ',
  },
  {
    'time': '13:45',
    'subject': 'Quản trị mạng, 64HTTT3',
    'room': '327-A2',
    'status': 'Nghỉ',
  },
];
